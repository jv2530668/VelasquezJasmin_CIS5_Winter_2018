/* 
 * File:   main.cpp
 * Author: Jasmin Velasquez
 * Created on February 05,2018, 12:30 PM
 *Purpose: To recreate the game MasterMind .
 */

//System Libraries
#include <iostream>
#include <iomanip>//Format Library
#include <cstdlib>
#include <ctime>//Time library for random seed
#include <string>

using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                      2-D Array Dimensions

//Function Prototypes
char* userGs();
 char* userGs(int turn);

//Execution Begins Here
int main(int argc, char** argv) {
   
    //Generate Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    char    in; //Variable for the users picked categories
    char* guess;//The users guesses for the correct sequence
    char code[4];// The 4 possible codes
    char gmestat;//game status 
    float color;//Correct colors
    int spot;//Correct spot
    static int trnleft=10;//turn left: static variable can basically live everywhere. it stays .
    string UsName;//Allows user to input name 
    float avg;// The percentage of your success rate .
    char turns;
    int correct;
   int wrong;
   
  
   
   //Game name
     cout<<"GAME: MASTER MIND [MOD] "<<endl;
    
    //Prompt used to pick one of the following categories
     do{
    cout<<"___________________________________________________________________________________________"<<endl;
    cout<<"\n Pick one of the following categories: "<<endl;
    cout<<" a. The purpose of the game "<<endl;
    cout<<" b. The directions of the game "<<endl;
    cout<<" c. Begin to play the  game "<<endl;
    cout<<"_____________________________________________________________________________________________"<<endl;
    cin>>in;//Users Input Choice
         
    //Lets the user know the purpose of the game
    if(in=='a' || in=='A')
    {
    cout<<"\n The purpose of this MODIFIED game is to have one player guess the secret code chosen by the other player."<<endl;
    cout<<"The code is a sequence of 4 colors chosen from 6 available colors. The code - breaker will pick"<<endl;
    cout<<"4 colors and the position they believe the code- maker arranged them in. The goal is to figure out"<<endl;
    cout<<"which colors are correct as well as arranged. The code - breaker will have 10"<<endl;
    cout<<"opportunities to guess the correct sequence and the 4 correct colors. If they surpass 10 opportunities"<<endl;
    cout<<"then it is GAME OVER ! "<<endl;    
    } 
     //Lets the user know the directions of the game
   if (in=='b' || in=='B'){
        cout<<" DIRECTIONS : "<<endl;\
    cout<<"\nThe following letters represent each color: R=Red, Y=Yellow, O=Orange ,B=Blue ,G=Green , and P=Purple"<<endl;
    cout<<" ENTER the letter of the 4 colors you think the code - maker chose. If you have "<<endl;
    cout<<"successfully picked the correct colors and arrangement of them, the computer will let you know the amount"<<endl;
    cout<<"of correct colors. WARNING: colors can be used multiple times! "<<endl;
    cout<<" GOOD LUCK ! "<<endl;
    } 
    }while(in!='c' && in!='C');
//Beginning of game if user picks choice c
    if(in=='c'|| in=='C'){
       
     //Loop for game /Code maker /Switch statement   
        //Randomizing code1
     srand(time(0));
for(int i=0; i < 4; i++){

        switch ((rand() % 6) + 1 )
       {
           case 1: code[i]='R';
           break;
           case 2: code[i]='Y';
           break;
           case 3: code[i]='G';
           break;
           case 4: code[i]='P';
           break;
           case 5: code[i]='O';
           break;
           case 6: code[i]='B';
           break;
          default: cout<<"error";
       }
}
       
    //Code Breaker        
 cout<<"Do you want to determine the amount of turns YES or nay? Enter Y or N."<<endl;
cin>>turns;//Allows user to determine whether or not they want to pick the amount of turns or not.
     correct=0;
     wrong=0;
    //This is were the user will input there there guesses
    int i=0;
    while(i<trnleft ){
        spot=0;
        color=0;
     if(turns=='Y'|| turns=='y'){
    
    if(i==0){
cout<<"How many turns do you want?"<<endl;
turns='N';
    }
int num;
cin>>num;
trnleft=num;
   //This is where i call userGs that takes in an integer
cout<<"\n The sequence is "<<code[0]<<" "<<code[1]<<" "<<code[2]<<" "<<code[3]<<"\n"<<endl;   
guess=userGs(num);
   
}
else{
 cout<<"\n The sequence is "<<code[0]<<" "<<code[1]<<" "<<code[2]<<" "<<code[3]<<"\n"<<endl;
 guess=userGs();//Users input
}
        
if(guess[i] == code[i]){
   correct++;
}
else {
 wrong++;
}
  i++;      
       cout<<"\nYou have "<<(trnleft-i)<<" turn left"<<endl;

    }      
        
       
    
        
        
         cout <<"\n"<<UsName<<" you got "<<fixed<<setprecision(0)<< color <<" in the correct position and color "<< endl;
       //Average of correct colors and positions guessed
          avg=static_cast<float>(color/4) * 100;
        cout<<"\n You got "<<fixed<<setprecision(2)<<avg<<" % correct "<<endl;
       //If the user runs out of turns this is what will be output
        if(trnleft==0){
            cout<<"\n"<<UsName<<" you have run out of turns";
//            cout<<"\n The sequence is "<<code[0]<<" "<<code[1]<<" "<<code[2]<<" "<<code[3];
            
            gmestat=false;//breaks out of the while loop
        
       
        }else if(color==4){//This is if the user gets all 4 colors and positions correctly
         
            cout<<"\nImpressive! "<<"\n"<<UsName<<" you WIN ! "<<endl;
           
            //This breaks out of the while loop
             gmestat=false;
        }
        
   
    }
    
    trnleft=10;
    //Exit Stage Right!
    return 0;

 
}


char* userGs()
{
    char guess[4];//Users guess for 4 colors
    
    //Prompt user to enter guess
    cout<<"Enter the following characters in Capital letters : ";
    cout<<"\nR=Red, Y=Yellow, O=Orange ,B=Blue ,G=Green , and P=Purple"<<endl;
    for(int i=0;i<4;i++){
    cout<<"\nEnter one letter at a time: ";
    cin>>guess[i];//user will be able to input 4 characters or there choice

    
    }   
    return guess;

}
char* userGs(int turn)
{
    int trnleft;
    char guess[4];//Users guess for 4 colors
   trnleft=turn;
   
   cout<<"Enter the following characters in Capital letters : ";
  cout<<"\nR=Red, Y=Yellow, O=Orange ,B=Blue ,G=Green , and P=Purple"<<endl;
   
    //Prompt user to enter guess
   for(int i=0;i<4;i++){
    cout<<"\nEnter one letter at a time: ";
    cin>>guess[i];//user will be able to input 4 characters or there choice
   }
    return guess;
}
